﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TechDistribution.GUI
{
    public partial class CreateEmployeeAccount : Form
    {
        public CreateEmployeeAccount()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void CreateEmployeeAccount_Load(object sender, EventArgs e)
        {

        }
    }
}
